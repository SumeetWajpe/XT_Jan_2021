export default class CMath {
}
export const PI = 3.14;
//PI = 3.123244;
function _Add(x, y) {
    return x + y;
}
