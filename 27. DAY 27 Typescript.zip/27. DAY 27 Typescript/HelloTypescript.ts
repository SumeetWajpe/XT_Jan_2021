//let x = 100; // Type inference
// x = "Hello";

let x: number; // Type annotation
let booleanVar: boolean;
let str: string;
let o: object;
let i: any;
i = "Anytype";
i = 100;
i = true;
i = { name: 'any' };
console.log(typeof i);

// functions

function Add(x: number, y: number): number | string {
    if (x > 0) {
        return x + y;
    } else {
        return "X should be greater than 0";
    }
}
//Add();
let result: number | string = Add(10, 20);
console.log('The result is : ' + result);

// optional parameters
// function PrintBooks(author: string, title?: string) {

// }

// PrintBooks('Ranjit Desai', "Mrutyunjay");

// Default paramters
// function PrintBooks(author: string = "Unknown", title: string = "Unknown") {
//     console.log(author, title)
// }

// PrintBooks();
// PrintBooks('Ranjit Desai', "Mrutyunjay");

function PrintBooks(author: string = "Unknown", ...titles: string[]) {
    console.log(author, titles)
}

PrintBooks();
PrintBooks('Ranjit Desai', "Mrutyunjay", "Chava", "Radhey");

// Arrays
let strArray: string[] = ['HTML5', 'CSS3', 'Typescript'];

// OR
// (Generics)
let strArrayGen: Array<string> = new Array<string>();


let Square = (x: number): number => { return x * x };
console.log(Square(20));


// Interfaces
interface ICompany {
    name: string;
    location?: string;
    printDetails?(): void;
}
var company: ICompany = { name: 'Sapient' };

let arrayOfCOmpanies: ICompany[] = [
    { name: 'IBM', location: 'Pune' },
    { name: 'Accenture', location: 'Pune' },
    { name: 'Microsoft', location: 'Hyderabad' },
    { name: 'Sapient', location: 'Bengaluru' }
];

enum Designation {
    Developer = 100,
    Tester,
    TeamLead,
    Architect
}

let designation: Designation;
designation = Designation.Tester;
console.log(designation); // number value
console.log(Designation[designation]); // string representation

// Classes

class Car {
    private id: number; // private, public , protected
    name: string;
    speed: number;

    // constructor();
    // constructor(name:string);
    // constructor(name:string,speed:number);
    // constructor(name?:string,speed?:number){
    //     this.id=10;
    //     this.name = name;
    //     this.speed = speed;
    // }

    constructor(name: string = "i20", speed: number = 100) {
        this.id = 10;
        this.name = name;
        this.speed = speed;
    }
    accelerate(): string {
        return `The Car ${this.name} is running at ${this.speed} kmph !`;
    }
}
// new Car();
// new Car("Hyundai Accent");
// let carObj:Car = new Car("Honda City",200);
// console.log(carObj.name,carObj.speed);
// carObj.accelerate();

class JamesBondCar extends Car {
    useNitroPower: boolean;
    constructor(name: string, speed: number, nitro: boolean) {
        super(name, speed);
        this.useNitroPower = nitro;
    }
    accelerate(): string {
        return super.accelerate() + ' Using Nitro Power ? ' + this.useNitroPower;
    }
}

let jbc: JamesBondCar = new JamesBondCar("Aston Martin", 500, true);
console.log(jbc.accelerate());


interface IPerson {
    name: string;
    age: number;
}
interface IEmployee {
    id: number;
    salary: number;
    // getSalary():number;
    getSalary: () => number; // with Function type
}

class CPerson implements IPerson, IEmployee {
    name: string;
    age: number;
    id: number;
    salary: number;
    getSalary(): number {
        return this.salary;
    }
}

let emp: CPerson = new CPerson();
// Function Types (parameter list=> return type)

class CFile {
    save(callbackFunction: (fileName: string) => string) {

    }
}

let f: CFile = new CFile();
// f.save(function(){

// })

function BinaryOp(theOperation: (x: number, y: number) => number) {
    let theResult = theOperation(10, 20);
    console.log(theResult);
}

BinaryOp(function (x: number, y: number): number {
    return x + y;
});

BinaryOp((x: number, y: number): number => x + y);
BinaryOp((x: number, y: number): number => x - y);
BinaryOp((x: number, y: number): number => x * y);
BinaryOp((x: number, y: number): number => x / y);

// Generics
let cars: Array<string> = new Array<string>();
cars[0] = "BMW";
//cars[1] = 123;


function Swap<T>(x: T, y: T): void {
    let temp: T;
    temp = x;
    x = y;
    y = temp;
    console.log(x, y);
}

Swap<number>(10, 20);
Swap<string>(" World !", "Hello");



class Point<T>{
    x: T;
    y: T;
}


let pointAsNumber: Point<number> = new Point<number>();

// Enhanced Class Syntax
class EnhancedProduct {
    constructor(
        public title?: string,
        public price?: number,
        public rating?: number,
        public likes?: number,
        public imageUrl?: string
    ) {

    }
}

let productInstance: EnhancedProduct = new EnhancedProduct();
console.log(productInstance.title)

// database 
//id,title,rating,likes
// Tuples
let tupleVar: [string, number, number];
tupleVar = ["Tuple", 10, 10];
console.log(tupleVar[0]);

let TwoDArray: Array<[number, number]> = [[10, 20], [30, 40]];