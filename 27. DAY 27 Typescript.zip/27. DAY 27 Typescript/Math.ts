export default class CMath {
    x: number;
    y: number;
}

export const PI: number = 3.14;
//PI = 3.123244;

function _Add(x: any, y: any) {
    return x + y
}