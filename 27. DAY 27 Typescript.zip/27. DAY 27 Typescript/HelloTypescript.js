//let x = 100; // Type inference
// x = "Hello";
let x; // Type annotation
let booleanVar;
let str;
let o;
let i;
i = "Anytype";
i = 100;
i = true;
i = { name: 'any' };
console.log(typeof i);
// functions
function Add(x, y) {
    if (x > 0) {
        return x + y;
    }
    else {
        return "X should be greater than 0";
    }
}
//Add();
let result = Add(10, 20);
console.log('The result is : ' + result);
// optional parameters
// function PrintBooks(author: string, title?: string) {
// }
// PrintBooks('Ranjit Desai', "Mrutyunjay");
// Default paramters
// function PrintBooks(author: string = "Unknown", title: string = "Unknown") {
//     console.log(author, title)
// }
// PrintBooks();
// PrintBooks('Ranjit Desai', "Mrutyunjay");
function PrintBooks(author = "Unknown", ...titles) {
    console.log(author, titles);
}
PrintBooks();
PrintBooks('Ranjit Desai', "Mrutyunjay", "Chava", "Radhey");
// Arrays
let strArray = ['HTML5', 'CSS3', 'Typescript'];
// OR
// (Generics)
let strArrayGen = new Array();
let Square = (x) => { return x * x; };
console.log(Square(20));
var company = { name: 'Sapient' };
let arrayOfCOmpanies = [
    { name: 'IBM', location: 'Pune' },
    { name: 'Accenture', location: 'Pune' },
    { name: 'Microsoft', location: 'Hyderabad' },
    { name: 'Sapient', location: 'Bengaluru' }
];
var Designation;
(function (Designation) {
    Designation[Designation["Developer"] = 100] = "Developer";
    Designation[Designation["Tester"] = 101] = "Tester";
    Designation[Designation["TeamLead"] = 102] = "TeamLead";
    Designation[Designation["Architect"] = 103] = "Architect";
})(Designation || (Designation = {}));
let designation;
designation = Designation.Tester;
console.log(designation); // number value
console.log(Designation[designation]); // string representation
// Classes
class Car {
    // constructor();
    // constructor(name:string);
    // constructor(name:string,speed:number);
    // constructor(name?:string,speed?:number){
    //     this.id=10;
    //     this.name = name;
    //     this.speed = speed;
    // }
    constructor(name = "i20", speed = 100) {
        this.id = 10;
        this.name = name;
        this.speed = speed;
    }
    accelerate() {
        return `The Car ${this.name} is running at ${this.speed} kmph !`;
    }
}
// new Car();
// new Car("Hyundai Accent");
// let carObj:Car = new Car("Honda City",200);
// console.log(carObj.name,carObj.speed);
// carObj.accelerate();
class JamesBondCar extends Car {
    constructor(name, speed, nitro) {
        super(name, speed);
        this.useNitroPower = nitro;
    }
    accelerate() {
        return super.accelerate() + ' Using Nitro Power ? ' + this.useNitroPower;
    }
}
let jbc = new JamesBondCar("Aston Martin", 500, true);
console.log(jbc.accelerate());
class CPerson {
    getSalary() {
        return this.salary;
    }
}
let emp = new CPerson();
// Function Types (parameter list=> return type)
class CFile {
    save(callbackFunction) {
    }
}
let f = new CFile();
// f.save(function(){
// })
function BinaryOp(theOperation) {
    let theResult = theOperation(10, 20);
    console.log(theResult);
}
BinaryOp(function (x, y) {
    return x + y;
});
BinaryOp((x, y) => x + y);
BinaryOp((x, y) => x - y);
BinaryOp((x, y) => x * y);
BinaryOp((x, y) => x / y);
// Generics
let cars = new Array();
cars[0] = "BMW";
//cars[1] = 123;
function Swap(x, y) {
    let temp;
    temp = x;
    x = y;
    y = temp;
    console.log(x, y);
}
Swap(10, 20);
Swap(" World !", "Hello");
class Point {
}
let pointAsNumber = new Point();
// Enhanced Class Syntax
class EnhancedProduct {
    constructor(title, price, rating, likes, imageUrl) {
        this.title = title;
        this.price = price;
        this.rating = rating;
        this.likes = likes;
        this.imageUrl = imageUrl;
    }
}
let productInstance = new EnhancedProduct();
console.log(productInstance.title);
// database 
//id,title,rating,likes
// Tuples
let tupleVar;
tupleVar = ["Tuple", 10, 10];
console.log(tupleVar[0]);
