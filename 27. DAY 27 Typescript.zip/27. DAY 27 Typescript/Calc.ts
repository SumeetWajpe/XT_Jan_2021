import MathClass, { PI } from './Math';
console.log(PI);