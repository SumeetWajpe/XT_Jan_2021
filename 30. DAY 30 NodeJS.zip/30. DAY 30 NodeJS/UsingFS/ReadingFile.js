var fs = require("fs");

// Non-blocking
fs.readFile("Input.txt", function (err, dataFromTheFile) {
  if (err) console.log("Error : " + err);
  else console.log("Read File (Async) : " + dataFromTheFile.toString());
});

// blocking
// var dataFromTheFile = fs.readFileSync("Input.txt");
// console.log("Read File (Sync) : " + dataFromTheFile.toString());

console.log("Program Ended !");
