var fs = require("fs");

let allFileData = "";
var readStream = fs.createReadStream("Data.txt");
var writeStream = fs.createWriteStream("Output.txt");
// Non-Blocking
readStream.on("data", function (dataChunck) {
  allFileData +=
    ">>>>>>>>>>>>>>>>>>>> READING CHUNK>>>>>>>>>>>>>>>>>>>>>>" + dataChunck;
});

// readStream.on("end", function () {
//   writeStream.write(allFileData);
//   writeStream.end(); // end of writing !
// });

readStream.pipe(writeStream); // control flow is managed automatically !

// Flow

// 1.Creating a temp variable
//2. fs- Read and emit data ( creates a buffer,when buffer is full emit data)
//3. Handle the data emitting event append to temp variable
// 3.1  clear the buffer
// 4. When fs is done reading the complete file
//5. write it on the wriatble stream.
