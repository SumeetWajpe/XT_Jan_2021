import { Addition } from "./addmodule.js";

QUnit.module("add", function () {
  QUnit.test("should add two numbers", function (assert) {
    assert.equal(Addition(10, 10), 30, "10 + 10 = 20");
  });
});
