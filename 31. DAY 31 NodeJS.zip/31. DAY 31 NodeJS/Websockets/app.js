const http = require("http");
var socket = require("socket.io");
const fs = require("fs");

const hostname = "127.0.0.1";
const port = 3000;

// create a server
const server = http.createServer((req, res) => {
  console.log("Generating Response !");
  res.statusCode = 200;
  res.setHeader("Content-Type", "text/html");
  fs.readFile("ClientPeer.html", function (err, dataFromFile) {
    res.end(dataFromFile);
  });
});

// make socket  listen on the same server
var io = socket(server);
io.sockets.on("connection", function (skt) {
  // sent / emit event to client peer
  setInterval(function () {
    var dataToBeSent = new Date();
    skt.emit("custom_messagefrom_serverpeer", dataToBeSent);
  }, 2000);

  // receive data from client peer
  skt.on("custom_messagefrom_clientpeer", function (dataFromClientPeer) {
    console.log("Data from Client Peer : " + dataFromClientPeer);
  });
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
