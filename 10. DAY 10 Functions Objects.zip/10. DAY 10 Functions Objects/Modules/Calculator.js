import Addition, { Product } from "./Math.js";
console.log("The addition is : " + Addition(20, 30));
console.log("The product is : " + Product(20, 30));
