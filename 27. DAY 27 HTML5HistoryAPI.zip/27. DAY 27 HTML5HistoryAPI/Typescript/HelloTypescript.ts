//let x = 100; // Type inference
// x = "Hello";

let x: number; // Type annotation
let booleanVar: boolean;
let str: string;
let o: object;
let i: any;
i = "Anytype";
i = 100;
i = true;
i = { name: 'any' };
console.log(typeof i);

// functions

function Add(x: number, y: number): number | string {
    if (x > 0) {
        return x + y;
    } else {
        return "X should be greater than 0";
    }
}
//Add();
let result: number | string = Add(10, 20);
console.log('The result is : ' + result);

// optional parameters
// function PrintBooks(author: string, title?: string) {

// }

// PrintBooks('Ranjit Desai', "Mrutyunjay");

// Default paramters
// function PrintBooks(author: string = "Unknown", title: string = "Unknown") {
//     console.log(author, title)
// }

// PrintBooks();
// PrintBooks('Ranjit Desai', "Mrutyunjay");

function PrintBooks(author: string = "Unknown", ...titles: string[]) {
    console.log(author, titles)
}

PrintBooks();
PrintBooks('Ranjit Desai', "Mrutyunjay", "Chava", "Radhey");

// Arrays
let strArray: string[] = ['HTML5', 'CSS3', 'Typescript'];

// OR
// (Generics)
let strArrayGen: Array<string> = new Array<string>();

