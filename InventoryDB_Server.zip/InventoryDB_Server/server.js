const express = require("express");
var cors = require("cors");
var reportsObj = require("./data/reports.json");
var unitsObj = require("./data/units.json");
var adminObj = require("./data/administrator.json");
var settingsObj = require("./data/settings.json");
var userunitsObj = require("./data/userunits.json");

const { response } = require("express");
var app = express(); // one application
var router = express.Router(); // server side router

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({ extended: true }));

// Parse JSON bodies (as sent by API clients)
app.use(express.json());
app.use(cors()); // sets the header instead !

// Reports API
// Method:GET , API -> /reports
router.get("/reports", function (req, res) {
  res.json(reportsObj); //converts js object to JSON
});
// Method:POST , API -> /reports
router.post("/reports", function (req, res) {
  console.log(req.body.report);

  reportsObj.push({
    id: req.body.report.id,
    name: req.body.report.name,
    type: req.body.report.type,
    assignedto: req.body.report.assignedto,
    status: req.body.report.status,
    from: req.body.report.from,
  });
  // res.json(reportsObj); //converts js object to JSON
  // OR
  res.json({ success: "Record Inserted successfully" });
});

// Units API
// Method:GET , API -> /units
router.get("/units", function (req, res) {
  res.json(unitsObj); //converts js object to JSON
});

// Method:POST , API -> /units
router.post("/units", function (req, res) {
  console.log(req.body.unit);
  unitsObj.push({
    id: req.body.report.id,
    name: req.body.unit.name,
    type: req.body.unit.type,
    assignedto: req.body.unit.assignedto,
    status: req.body.unit.status,
    from: req.body.unit.from,
  });
  // res.json(unitsObj); //converts js object to JSON
  // OR
  res.json({ success: "Record Inserted successfully" });
});

// UserUnits API
router.get("/userunits", function (req, res) {
  res.json(userunitsObj); //converts js object to JSON
});

// Method:POST , API -> /units
router.post("/userunits", function (req, res) {
  console.log(req.body.userunit); // data received from client side (within request object)
  userunitsObj.push({
    id: req.body.report.id,
    name: req.body.userunit.name,
    type: req.body.userunit.type,
    username: req.body.userunit.username,
    email: req.body.userunit.email,
    skype: req.body.userunit.skype,
    _id: req.body.userunit.name + Math.random(),
    from: req.body.userunit.from,
  });
  // res.json(userunitsObj); //converts js object to JSON
  // OR
  res.json({ success: "Record Inserted successfully" });
});

// Administrator API
//Method:GET , API -> /administrator
router.get("/administrator", function (req, res) {
  res.json(adminObj); //converts js object to JSON
});

// Settings API
router.get("/settings", function (req, res) {
  res.json(settingsObj); //converts js object to JSON
});

// Method:POST , API -> /settings
router.post("/settings", function (req, res) {
  console.log(req.body.setting); // data received from client side (within request object)
  settingsObj.push({
    id: req.body.setting.setting.id,
    name: req.body.setting.name,
    shortname: req.body.setting.shortname,
    properties: req.body.setting.properties,
    parts: req.body.setting.parts,
  });
  // res.json(userunitsObj); //converts js object to JSON
  // OR
  res.json({ success: "Record Inserted successfully" });
});

// Home Url (Optional and do not use)
router.get("/", function (req, res) {
  res.sendFile("client.html", { root: __dirname });
});

app.use(router);
app.listen(4000, () => console.log("Server running @ 4000 !"));
