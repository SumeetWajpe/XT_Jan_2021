// executed by the Worker thread

onmessage = function (dataFromMainThread) {
  console.log(XMLHttpRequest);
  console.log("Received Data from Main Thread : " + dataFromMainThread.data);
  let largeArray = [];
  for (let index = 0; index < 5000; index++) {
    largeArray[index] = [];

    for (let j = 0; j < 5000; j++) {
      largeArray[index][j] = Math.random();
    }
  }

  postMessage(largeArray[2000][3000]); // send data to main thread (script)
};
