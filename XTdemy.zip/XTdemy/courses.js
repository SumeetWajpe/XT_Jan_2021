class Course {
  constructor(id, name, price, likes, rating, imageUrl) {
    this.id = id;
    this.name = name;
    this.price = price;
    this.likes = likes;
    this.rating = rating;
    this.imageUrl = imageUrl;
  }
}

let listOfCourses = [
  new Course(
    1,
    "React",
    4000,
    200,
    4,
    "https://miro.medium.com/max/3840/1*yjH3SiDaVWtpBX0g_2q68g.png"
  ),
  new Course(
    2,
    "Angular",
    3000,
    400,
    4,
    "https://www.freecodecamp.org/news/content/images/2020/04/Copy-of-Copy-of-Travel-Photography.png"
  ),
  new Course(
    3,
    "Typescript",
    3000,
    200,
    5,
    "https://miro.medium.com/max/4000/1*9eMyWLYOqU5aqBtVoFoi3Q.jpeg"
  ),
  new Course(
    4,
    "Node",
    6000,
    200,
    5,
    "https://i2.wp.com/itsfoss.com/wp-content/uploads/2016/05/node-js-background.jpeg?fit=800%2C450&ssl=1"
  ),
  new Course(
    5,
    "Vue",
    4000,
    200,
    5,
    "https://i1.wp.com/storage.googleapis.com/blog-images-backup/1*wFL3csJ96lQpY0IVT9SE3w.jpeg?ssl=1"
  ),
];

function GenerateCourses() {
  for (let course of listOfCourses) {
    DisplayCourseItem(course);
  }
}
GenerateCourses();

function DisplayCourseItem(course) {
  var courseCard = document.createElement("div");
  //divParent.setAttribute("class","ParentCourseItem");
  courseCard.className = "course-card";

  // set properties of Course Name
  var courseName = document.createElement("h2");
  courseName.innerHTML = course.name;
  courseName.setAttribute("style", "font-family: Roboto;margin:0.5em");

  // row div
  var cardHeaderandButton = document.createElement("div");
  cardHeaderandButton.className = "card-header";

  cardHeaderandButton.appendChild(courseName);

  // delete button
  var courseDeleteBtn = document.createElement("button");
  courseDeleteBtn.className = "action-delete-btn";

  var courseDeleteGlyph = document.createElement("i");
  courseDeleteGlyph.setAttribute("class", "fas fa-trash fa-lg");

  courseDeleteBtn.addEventListener("click", function () {
    // Delete Courses here..
  });

  courseDeleteBtn.appendChild(courseDeleteGlyph);

  cardHeaderandButton.appendChild(courseDeleteBtn);

  let cardBody = document.createElement("div");
  cardBody.setAttribute(
    "style",
    "display:flex;flex-direction:column;justify-content: space-evenly;"
  );

  // set properties of Course Price
  var coursePrice = document.createElement("strong");
  coursePrice.innerHTML = "Price : " + course.price;
  coursePrice.setAttribute(
    "style",
    "margin:0px;margin-top:0.5em;padding:0px;font-family: 'Open Sans', sans-serif"
  );

  cardBody.appendChild(coursePrice);
  // set properties of Course Rating
  var courseRating = document.createElement("strong");
  courseRating.innerHTML = "Rating : " + course.rating;
  courseRating.setAttribute(
    "style",
    "margin:0px;margin-top:0.5em;padding:0px;font-family: 'Open Sans', sans-serif"
  );

  cardBody.appendChild(courseRating);

  // set properties of Course Likes Button
  var courseLikesBtn = document.createElement("button");
  courseLikesBtn.setAttribute(
    "style",
    "background-color:white;border:0px;margin-top:1em;cursor:pointer;font-size:1.2em;outline:none;color:rgb(69, 161, 231); font-family: 'Open Sans', sans-serif"
  ); // bad stayling (use class)

  courseLikesBtn.innerHTML = course.likes;

  // likes glyphicon
  var courseLikesSpanGlyph = document.createElement("i");
  courseLikesSpanGlyph.className = "far fa-thumbs-up fa-lg";

  courseLikesBtn.appendChild(courseLikesSpanGlyph);

  // use addEventListener
  courseLikesBtn.onclick = function () {
    course.likes += 1;
    courseLikesBtn.innerHTML = course.likes;
    courseLikesBtn.appendChild(courseLikesSpanGlyph);
  };

  // set properties of Course Image
  var courseImage = document.createElement("img");
  courseImage.setAttribute("src", course.imageUrl);
  courseImage.setAttribute("width", "100%");

  courseCard.appendChild(cardHeaderandButton);
  courseCard.appendChild(courseImage);
  courseCard.appendChild(cardBody);

  courseCard.appendChild(courseLikesBtn);

  var root = document.querySelector("main");

  root.appendChild(courseCard);
}
