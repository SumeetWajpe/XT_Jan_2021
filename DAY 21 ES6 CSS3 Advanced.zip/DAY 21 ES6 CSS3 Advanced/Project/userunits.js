function InitializeUserUnits() {
  let thePromise = FetchDataFromEndpoint(
    "https://inventorydb-3f0f.restdb.io/rest/unittypes"
  );
  thePromise
    .then(
      (response) =>
        (document.querySelector("#targetDiv").innerHTML = JSON.stringify(
          response
        ))
    )
    .catch((err) => console.log(err));
}
