var a,
  x,
  y = 30;
console.log(y);
function TestX() {
  var x = 20;
  console.log(x);
}
