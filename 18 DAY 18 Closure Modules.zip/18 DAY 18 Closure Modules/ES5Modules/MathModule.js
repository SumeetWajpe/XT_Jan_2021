var MathModule = (function () {
  var Pie = 3.14; // private
  function Add(x, y) {
    return x + y;
  }
  function Product(x, y) {
    return x * y;
  }

  return {
    Addition: Add,
    Multiplication: Product,
  };
})();
// Global namespace pollution
function Test() {}
